








local utf8display = require("Lib.utf8display")

local M = {}

M.utf8display = utf8display



local function padColor(colorStr, len)
  if type(colorStr) ~= "string" or #colorStr == 0 then return colorStr end
  if #colorStr >= len then return colorStr end
  return colorStr .. string.rep(colorStr:sub(-1), len - #colorStr)
end





function M.ProcessStrToBimg(text, fgColor, bgColor)
  text = tostring(text or "")
  local textLen = utf8display and (utf8.len and utf8.len(text)) or #text
  if not textLen then textLen = #text end
  local fg = padColor(fgColor, textLen)
  local bg = padColor(bgColor, textLen)
  return utf8display.strToBimg(text, fg, bg)
end



function M.asFramed(x)
  if type(x) ~= "table" then return { { { "", "", "" } } } end
  if type(x[1]) == "table" and type(x[1][1]) == "table" then return x end
  return { x }
end


function M.ConcatBimg(a, b)
  a = M.asFramed(a)
  b = M.asFramed(b)
  local result = {}
  for i = 1, #a do
    result[i] = {}
    for j = 1, #a[i] do
      result[i][j] = {}
      for k = 1, #a[i][j] do
        result[i][j][k] = a[i][j][k] .. b[i][j][k]
      end
    end
  end
  return result
end


function M.widthOf(bimg)
  local frame = M.asFramed(bimg)[1]
  local w = 0
  for _, row in ipairs(frame) do
    if #row[1] > w then w = #row[1] end
  end
  return w
end


function M.heightOf(bimg)
  return #M.asFramed(bimg)[1]
end



function M.glyphHeight()
  local ok, bimg = pcall(M.ProcessStrToBimg, "A", "Q", "B")
  if not ok or type(bimg) ~= "table" then return 3 end
  local h = M.heightOf(bimg)
  if h < 1 then h = 3 end
  return h
end

return M
