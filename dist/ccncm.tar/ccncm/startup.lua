















package.path = "/?.lua;/?/init.lua;" .. package.path




local okData, data = pcall(require, "ccncm.data")
local printNative
if okData and type(data.printNative) == "function" then
  printNative = data.printNative
else
  printNative = function(...)
    local parts = {}
    for i = 1, select("#", ...) do
      parts[i] = tostring((select(i, ...)))
    end
    local line = table.concat(parts, "\t")
    local previous = term.current()
    local ok = pcall(function()
      term.redirect(term.native())
      pcall(term.setTextColor, colors.white)
      pcall(term.setBackgroundColor, colors.black)
      print(line)
    end)
    pcall(term.redirect, previous)
    return ok
  end
end




local function asciiSafe(text)
  return (tostring(text or ""):gsub("[\128-\255]", "?"))
end



local function resetNative()
  pcall(function()
    local native = term.native()
    native.setBackgroundColor(colors.black)
    native.setTextColor(colors.white)
    native.clear()
    native.setCursorPos(1, 1)
  end)
end

local function fail(msg)
  resetNative()
  printNative("CC-CloudMusicNCM - cannot start")
  printNative(asciiSafe(msg))
  printNative("")
  printNative("Prerequisites:")
  printNative("  - A monitor block attached to this computer")
  printNative("  - Advanced computer with HTTP enabled")
  printNative("  - the ncm library installed at /ncm (require \"ncm\")")
  printNative("  - a CJK font: /ccncm_font.lua, or network access to the")
  printNative("    default remote font used by Lib/utf8display.lua")
  printNative("See README.md for installation instructions.")
end





local monitor
if peripheral and type(peripheral.find) == "function" then
  monitor = peripheral.find("monitor")
end

if not monitor then
  resetNative()
  printNative("CC-CloudMusicNCM requires a monitor. Place a monitor block next to this computer and restart. Recommended: 3x2 blocks (2x2 minimum).")
  return
end



pcall(function() monitor.setTextScale(0.5) end)
local mw, mh = 0, 0
if type(monitor.getSize) == "function" then
  local okSize, w, h = pcall(monitor.getSize)
  if okSize then
    mw, mh = tonumber(w) or 0, tonumber(h) or 0
  end
end
if mw < 51 or mh < 19 then
  printNative(string.format(
    "warning: monitor is %dx%d but the layout needs 51x19. Recommended: 3x2 blocks (2x2 minimum). Continuing.",
    mw, mh))
end







if not pcall(function() term.redirect(monitor) end) then
  fail("cannot redirect the terminal to the monitor")
  return
end





local okApp, app = pcall(require, "ccncm.app")
if not okApp then
  fail(app)
  return
end

local okBuild, built, buildErr = pcall(app.build)
if not okBuild then
  fail(built)
  return
end
if built == false or built == nil then
  fail(buildErr or "unknown build error")
  return
end




local okRun, runErr = pcall(app.run)
pcall(function() term.redirect(term.native()) end)
resetNative()
if not okRun then
  fail(runErr)
end
